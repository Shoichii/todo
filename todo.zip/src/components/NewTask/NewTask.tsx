import { useAppSelector } from "../../hooks/hooks"
import { addTask } from "../../redux/appSlice";
import { changeDescription, changeTitle } from "../../redux/newTaskSlice";
import { useAppDispatch } from './../../hooks/hooks';
import NewTaskStyle from './NewTask.module.css';


export const NewTask: React.FC = () => {
    const state = useAppSelector(state => state.newTaskSlice)
    const dispatch = useAppDispatch();

    const onChangeTitle = (e: React.ChangeEvent<HTMLInputElement> ): void => {
        dispatch(changeTitle(e.currentTarget.value))
    }

    const onChangeDescription = (e: React.ChangeEvent<HTMLTextAreaElement> ): void => {
        dispatch(changeDescription(e.currentTarget.value))
    }

    const onAddTask = (e: React.MouseEvent<HTMLButtonElement>): void => {
        dispatch(addTask({title: state.textTitleValue, description: state.textDescriptionValue}))
        dispatch(changeTitle(''))
        dispatch(changeDescription(''))
    }
    
    return (
        <div className= {NewTaskStyle.main}>
            <input className= {NewTaskStyle.title} 
            type="text" name="titleOfNewTasknewtask" id="titleOfNewTask" 
            placeholder='введите заголовок' value = {state.textTitleValue} 
            onChange = {(e) => onChangeTitle(e)}/>

            <textarea className= {NewTaskStyle.description} 
            name="textOfNewTask" id="textOfNewTask" 
            placeholder='введите текст' value = {state.textDescriptionValue}
            onChange = {(e) => onChangeDescription(e)}></textarea>
            
            <button className= {NewTaskStyle.button} onClick={e => onAddTask(e)}>Добавить</button>
        </div>
    )
}
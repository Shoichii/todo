import { useAppDispatch } from '../../hooks/hooks';
import { deleteTask } from '../../redux/appSlice';
import TaskStyles from './Task.module.css';

interface IProps {
    title: string;
    description: string;
    index: number;
}


export const Task: React.FC<IProps> = (props) => {

    const dispatch = useAppDispatch();
    
    const delTask = (e: any): void => {
        dispatch(deleteTask(props.index) )
    }

    return (
        <div className= {TaskStyles.main}>
            <div className={TaskStyles.task}>
                <p className= {TaskStyles.title}>{props.title}</p>
                <p className={TaskStyles.description}>{props.description}</p>
            </div>
            <div className= {TaskStyles.buttons}>
                <button className={TaskStyles.change}>изменить</button>
                <button className={TaskStyles.delete} onClick={e => delTask(e)}>удалить</button>
            </div>
        </div>
    )
}
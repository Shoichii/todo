
import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface IInitialState {
    tasks: Array<{title: string, description: string, id: number}>;
}

const initialState: IInitialState = {
    tasks: [],
}

export const appSlice = createSlice({
    name: 'appSlice',
    initialState,
    reducers: {
        addTask: (state, action: PayloadAction<{title: string, description: string, id?: number}>) => {
            state.tasks.push({...action.payload, id: state.tasks.length})},

        deleteTask: (state, action: PayloadAction<number>) => {
            state.tasks.splice(action.payload,1);
        }
    }
})

export const {addTask, deleteTask} = appSlice.actions;

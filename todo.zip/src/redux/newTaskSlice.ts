import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface IInitialState {
  textTitleValue: string;
  textDescriptionValue: string
}

const initialState: IInitialState = {
  textTitleValue: '',
  textDescriptionValue: ''
}

export const newTaskSlice = createSlice({
    name: 'test',
    initialState,
    reducers: {
      changeTitle: (state, action: PayloadAction<string>) => {state.textTitleValue = action.payload},
      changeDescription: (state, action: PayloadAction<string>) => {state.textDescriptionValue = action.payload},
    },
  })

  export const {changeTitle,  changeDescription} = newTaskSlice.actions;